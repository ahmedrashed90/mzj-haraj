<?php
/**
 * Plugin Name: MZJ Haraj Ad Data Bridge
 * Description: Read-only bridge for MZJ Haraj Manager. Exposes vehicle identity, price and real MZJ Panorama/CompareKey specifications for ad-copy generation.
 * Version: 1.0.0
 * Author: MZJ CARS
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

final class MZJ_Haraj_Ad_Data_Bridge {
    const VERSION = '1.0.0';
    const REST_NS = 'mzj-haraj/v1';
    const OPT_SECRET = 'mzj_haraj_ad_bridge_secret';
    const SHARED_SECRET = 'mzj_platform_cars_bridge_secret';

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'routes'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_mzj_haraj_bridge_regenerate', array(__CLASS__, 'regenerate'));
    }
    public static function activate() {
        if (!get_option(self::OPT_SECRET) && !get_option(self::SHARED_SECRET)) add_option(self::OPT_SECRET, self::new_secret(), '', false);
    }
    private static function new_secret() { return 'mzjh_' . wp_generate_password(48, false, false); }
    private static function secret() {
        $shared = trim((string)get_option(self::SHARED_SECRET, ''));
        if ($shared !== '') return $shared;
        $own = trim((string)get_option(self::OPT_SECRET, ''));
        if ($own === '') { $own = self::new_secret(); update_option(self::OPT_SECRET, $own, false); }
        return $own;
    }
    public static function routes() {
        register_rest_route(self::REST_NS, '/ping', array('methods'=>WP_REST_Server::READABLE,'callback'=>array(__CLASS__,'ping'),'permission_callback'=>'__return_true'));
        register_rest_route(self::REST_NS, '/cars', array(
            'methods'=>WP_REST_Server::READABLE,
            'callback'=>array(__CLASS__,'cars'),
            'permission_callback'=>array(__CLASS__,'authorized'),
            'args'=>array('per_page'=>array('default'=>500,'sanitize_callback'=>'absint')),
        ));
    }
    public static function authorized(WP_REST_Request $request) {
        $provided = trim((string)$request->get_header('x-mzj-bridge-key'));
        if ($provided === '') { $auth = trim((string)$request->get_header('authorization')); if (stripos($auth, 'Bearer ') === 0) $provided = trim(substr($auth, 7)); }
        $expected = self::secret();
        if ($provided === '' || !hash_equals($expected, $provided)) return new WP_Error('mzj_haraj_forbidden','Invalid MZJ Haraj bridge key.',array('status'=>403));
        return true;
    }
    public static function ping() {
        return rest_ensure_response(array(
            'ok'=>true,'bridge'=>'MZJ Haraj Ad Data Bridge','version'=>self::VERSION,
            'panorama_loaded'=>class_exists('MZJPSN_Core') && class_exists('MZJPSN_Sheet'),
            'cars_endpoint'=>rest_url(self::REST_NS . '/cars'),'authentication'=>'X-MZJ-Bridge-Key',
        ));
    }
    private static function clean($value) { return trim(preg_replace('/\s+/u',' ',(string)$value)); }
    private static function spec_value($row, $field, $fallback='') {
        if (class_exists('MZJPSN_Sheet') && method_exists('MZJPSN_Sheet','value')) {
            $value = MZJPSN_Sheet::value((array)$row, $field, $fallback ?: '');
            return self::clean($value === '—' ? '' : $value);
        }
        return self::clean(isset($row[$field]) ? $row[$field] : $fallback);
    }
    private static function features($row, $field) {
        $raw = self::spec_value($row, $field, '');
        if ($raw === '') return array();
        if (class_exists('MZJPSN_Sheet') && method_exists('MZJPSN_Sheet','features')) return array_values(array_filter(array_map(array(__CLASS__,'clean'), MZJPSN_Sheet::features($raw))));
        $parts = preg_split('/\n+|\s*\|\s*|\s*;\s*/u', $raw);
        return array_values(array_unique(array_filter(array_map(array(__CLASS__,'clean'), (array)$parts))));
    }
    private static function first_term($post_id, $taxonomy) {
        $terms = wp_get_post_terms($post_id, $taxonomy, array('fields'=>'names'));
        return is_wp_error($terms) || !$terms ? '' : self::clean($terms[0]);
    }
    private static function fallback_car($post_id) {
        return array(
            'id'=>$post_id,'title'=>get_the_title($post_id),'vehicle_id'=>self::clean(get_post_meta($post_id,'vehicle_id',true)),
            'compare_key'=>self::clean(get_post_meta($post_id,'compare_key',true)),'price'=>(float)get_post_meta($post_id,'_price',true),
            'display_price'=>(float)get_post_meta($post_id,'_price',true),'make'=>self::first_term($post_id,'car_make'),'model'=>self::first_term($post_id,'car_model'),
            'trim'=>self::first_term($post_id,'car_trim'),'year'=>self::first_term($post_id,'car_year'),'body'=>self::first_term($post_id,'car_body_style'),
            'transmission'=>self::first_term($post_id,'car_transmission'),'drivetrain'=>self::first_term($post_id,'car_drivetrain'),'engine'=>self::first_term($post_id,'car_engine'),'fuel'=>self::first_term($post_id,'car_fuel_type'),
        );
    }
    private static function car_row($post_id) {
        $car = class_exists('MZJPSN_Core') && method_exists('MZJPSN_Core','car') ? MZJPSN_Core::car($post_id) : null;
        if (!is_array($car)) $car = self::fallback_car($post_id);
        $compare = self::clean(isset($car['compare_key']) ? $car['compare_key'] : '');
        if ($compare === '' && class_exists('MZJPSN_Core') && method_exists('MZJPSN_Core','resolve_compare_key')) $compare = self::clean(MZJPSN_Core::resolve_compare_key($post_id));
        $row = array();
        if ($compare !== '' && class_exists('MZJPSN_Sheet')) {
            if (method_exists('MZJPSN_Sheet','find_cached')) $row = MZJPSN_Sheet::find_cached($compare);
            if ((!is_array($row) || !$row) && method_exists('MZJPSN_Sheet','find')) $row = MZJPSN_Sheet::find($compare);
        }
        if (!is_array($row)) $row = array();
        $base_fields = array('المحرك','نوع الناقل','عدد السرعات','الدفع','نوع الوقود','استهلاك الوقود','الحصان الميكانيكي','عزم نيوتن','السرعة القصوى','عدد السلندرات','عدد المقاعد','الضمان','الطول مم','العرض مم','الارتفاع مم','قاعدة العجلات مم','حجم الشنطة مم');
        $base = array();
        foreach ($base_fields as $field) { $v = self::spec_value($row,$field,''); if ($v !== '') $base[$field] = $v; }
        if (empty($base['المحرك']) && !empty($car['engine'])) $base['المحرك'] = self::clean($car['engine']);
        if (empty($base['نوع الناقل']) && !empty($car['transmission'])) $base['نوع الناقل'] = self::clean($car['transmission']);
        if (empty($base['الدفع']) && !empty($car['drivetrain'])) $base['الدفع'] = self::clean($car['drivetrain']);
        if (empty($base['نوع الوقود']) && !empty($car['fuel'])) $base['نوع الوقود'] = self::clean($car['fuel']);
        $price = isset($car['display_price']) ? (float)$car['display_price'] : (isset($car['price']) ? (float)$car['price'] : 0);
        return array(
            'post_id'=>(int)$post_id,'vehicle_id'=>self::clean(isset($car['vehicle_id'])?$car['vehicle_id']:''),'title'=>self::clean(isset($car['title'])?$car['title']:get_the_title($post_id)),
            'price'=>$price,'make'=>self::clean(isset($car['make'])?$car['make']:''),'model'=>self::clean(isset($car['model'])?$car['model']:''),'trim'=>self::clean(isset($car['trim'])?$car['trim']:''),'year'=>self::clean(isset($car['year'])?$car['year']:''),
            'body'=>self::clean(isset($car['body'])?$car['body']:''),'transmission'=>self::clean(isset($car['transmission'])?$car['transmission']:''),'drivetrain'=>self::clean(isset($car['drivetrain'])?$car['drivetrain']:''),'engine'=>self::clean(isset($car['engine'])?$car['engine']:''),'fuel'=>self::clean(isset($car['fuel'])?$car['fuel']:''),
            'compare_key'=>$compare,'permalink'=>get_permalink($post_id),'base_specs'=>$base,
            'interior_specs'=>self::features($row,'المواصفات الداخلية'),'exterior_specs'=>self::features($row,'المواصفات الخارجية'),'safety_specs'=>self::features($row,'مواصفات الأمان'),
        );
    }
    public static function cars(WP_REST_Request $request) {
        if (!post_type_exists('cars')) return new WP_Error('mzj_haraj_cars_missing','Cars post type is unavailable.',array('status'=>500));
        $limit = min(500, max(1, (int)$request->get_param('per_page')));
        $ids = get_posts(array('post_type'=>'cars','post_status'=>array('publish','draft'),'posts_per_page'=>$limit,'orderby'=>'ID','order'=>'DESC','fields'=>'ids','no_found_rows'=>true));
        $items = array(); foreach ((array)$ids as $post_id) $items[] = self::car_row((int)$post_id);
        return rest_ensure_response(array('ok'=>true,'items'=>$items,'count'=>count($items),'generated_at'=>gmdate('c'),'source'=>'MZJ Cars Panorama / CompareKey / WordPress read-only'));
    }
    public static function admin_menu() { add_options_page('MZJ Haraj Bridge','MZJ Haraj Bridge','manage_options','mzj-haraj-ad-bridge',array(__CLASS__,'admin_page')); }
    public static function regenerate() {
        if (!current_user_can('manage_options')) wp_die('Forbidden'); check_admin_referer('mzj_haraj_bridge_regenerate');
        // If the existing MZJ Platform bridge is installed, it remains the shared source of truth.
        if (trim((string)get_option(self::SHARED_SECRET,'')) === '') update_option(self::OPT_SECRET,self::new_secret(),false);
        wp_safe_redirect(admin_url('options-general.php?page=mzj-haraj-ad-bridge&regenerated=1')); exit;
    }
    public static function admin_page() {
        if (!current_user_can('manage_options')) return; $shared = trim((string)get_option(self::SHARED_SECRET,'')) !== ''; $secret = self::secret();
        echo '<div class="wrap"><h1>MZJ Haraj Ad Data Bridge</h1><p>جسر قراءة فقط لمواصفات السيارات وصيغة إعلان حراج. لا يعدل أي سيارة أو مواصفة.</p>';
        echo '<table class="widefat striped" style="max-width:900px"><tbody><tr><th>Endpoint</th><td><code>'.esc_html(rest_url(self::REST_NS.'/cars')).'</code></td></tr><tr><th>Header</th><td><code>X-MZJ-Bridge-Key</code></td></tr><tr><th>Secret</th><td><code style="word-break:break-all">'.esc_html($secret).'</code></td></tr><tr><th>المصدر</th><td>'.($shared?'نفس Secret الخاص بـ MZJ Platform Cars Bridge':'Secret مستقل لهذا البلجن').'</td></tr><tr><th>Panorama</th><td>'.(class_exists('MZJPSN_Core')?'متصل':'غير متاح').'</td></tr></tbody></table>';
        if (!$shared) { $url = wp_nonce_url(admin_url('admin-post.php?action=mzj_haraj_bridge_regenerate'),'mzj_haraj_bridge_regenerate'); echo '<p><a class="button" href="'.esc_url($url).'">توليد Secret جديد</a></p>'; }
        echo '</div>';
    }
}
register_activation_hook(__FILE__, array('MZJ_Haraj_Ad_Data_Bridge','activate'));
MZJ_Haraj_Ad_Data_Bridge::init();
