MZJ Haraj Ad Data Bridge v1.0.0
================================

بلجن مستقل للقراءة فقط. لا يعدل بلجن Panorama ولا السيارات.

التركيب:
1) ارفع ZIP من إضافات ووردبريس وثبته وفعله.
2) افتح: الإعدادات > MZJ Haraj Bridge.
3) انسخ الـ Secret الظاهر.
4) في Vercel أضف:
   MZJ_WORDPRESS_BASE_URL=https://mzjcars.com
   MZJ_HARAJ_BRIDGE_KEY=<SECRET>
5) Redeploy لمشروع MZJ Haraj Manager.

إذا كان MZJ Platform Cars Bridge موجودًا، هذا البلجن يعيد استخدام نفس Secret تلقائيًا.
Endpoint: /wp-json/mzj-haraj/v1/cars
Header: X-MZJ-Bridge-Key
