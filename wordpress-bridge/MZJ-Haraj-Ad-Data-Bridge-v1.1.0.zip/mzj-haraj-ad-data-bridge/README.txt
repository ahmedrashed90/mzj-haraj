MZJ Haraj Ad Data Bridge v1.1.0

Read-only WordPress bridge for MZJ Haraj Manager.

Authoritative rule:
- المواصفات الداخلية = CompareKey sheet row only
- المواصفات الخارجية = CompareKey sheet row only
- مواصفات الأمان = CompareKey sheet row only

The endpoint also returns compare_key_status and compare_key_found so the Haraj Manager can block an ad when CompareKey is missing, not found, or incomplete.

Endpoint:
/wp-json/mzj-haraj/v1/cars

Authentication:
X-MZJ-Bridge-Key

If MZJ Platform Cars Bridge is installed, this plugin reuses mzj_platform_cars_bridge_secret.
